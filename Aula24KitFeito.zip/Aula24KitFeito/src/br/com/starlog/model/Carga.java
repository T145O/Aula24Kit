package br.com.starlog.model;

/**
 * CAMADA MODEL (Modelo de Domínio)
 * Representa uma carga a ser despachada pela estação StarLog.
 * 
 * ATENÇÃO: Esta classe NÃO deve importar nenhum componente visual do Swing!
 */
public class Carga {
    private final String codigoRastreio;
    private final String categoria;
    private final double peso;
    private final double valorDeclarado;

    public Carga(String codigoRastreio, String categoria, double peso, double valorDeclarado) throws IllegalArgumentException{
        // TODO: BARREIRA FAIL-FAST (Missão 2)
        // 1. Código de rastreio não pode ser nulo ou vazio -> lançar 
        // IllegalArgumentException("Código de rastreio não pode ser nulo ou vazio.");
        if(codigoRastreio == null || codigoRastreio.isBlank()){
            throw new IllegalArgumentException("Código de rastreio não pode ser nulo ou vazio.");
        }
        // 2. Categoria não pode ser nula ou vazia -> lançar 
        // IllegalArgumentException("Categoria não pode ser nula ou vazia.");
        if(categoria == null || categoria.isBlank()){
            throw new IllegalArgumentException("Categoria não pode ser nula ou vazia.");
        }
        // 3. Peso deve ser estritamente maior que zero -> lançar 
        // IllegalArgumentException("Peso deve ser estritamente positivo (maior que zero).");
        if(peso < 0){
            throw new IllegalArgumentException("Peso deve ser estritamente positivo.");
        }
        // 4. Valor declarado deve ser maior que zero -> lançar 
        // IllegalArgumentException("Valor declarado deve ser maior que zero.");
        if(valorDeclarado < 0){
            throw new IllegalArgumentException("Valor declarado deve ser maior que zero.");
        }

        this.codigoRastreio = codigoRastreio.trim().toUpperCase();
        this.categoria = categoria.trim().toUpperCase();
        this.peso = peso;
        this.valorDeclarado = valorDeclarado;
    }

    public String getCodigoRastreio() {
        return codigoRastreio;
    }

    public String getCategoria() {
        return categoria;
    }

    public double getPeso() {
        return peso;
    }

    public double getValorDeclarado() {
        return valorDeclarado;
    }

    /**
     * Regra de Negócio: Cálculo do Seguro Espacial da Carga.
     * Cargas perigosas ou pesadas possuem taxa base diferenciada.
     */
    public double calcularSeguro() {
        // TODO: Regra de Negócio (Missão 2)
        // 1. Taxa base de 2% do valor declarado
        double taxa = valorDeclarado * 0.02;
        // 2. Se a categoria for "PERIGOSA" ou se o peso for superior a 100 kg,
        // adicionar sobretaxa fixa de R$ 150,00 de risco operacional.
        if(peso >= 100 || categoria == "PERIGOSA"){
            taxa += 150.00;
        }
        
        return taxa;
    }

    @Override
    public String toString() {
        return String.format("[%s] Categoria: %s | Peso: %.2f kg | Valor: R$ %.2f | Seguro: R$ %.2f",
                codigoRastreio, categoria, peso, valorDeclarado, calcularSeguro());
    }
}
